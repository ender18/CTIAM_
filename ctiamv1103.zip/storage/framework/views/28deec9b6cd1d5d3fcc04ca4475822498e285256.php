
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link href="css/mycss.css" rel="stylesheet">
  </head>
  <body style="background-image: url('images/certifieds/certified.jpg');
       background-size: 100%;
       background-image-resize: 6;">

    <div >
      <h1>Hola Mundo</h1>
    </div>


  </body>
</html>
<?php /**PATH C:\xampp\htdocs\ctiam\resources\views/management/certifiedCourse.blade.php ENDPATH**/ ?>