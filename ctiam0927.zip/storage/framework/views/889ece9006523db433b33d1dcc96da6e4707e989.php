



<?php $__env->startSection('cssandjs'); ?>

<link rel="stylesheet" href="//unpkg.com/leaflet/dist/leaflet.css" />


<script src="//unpkg.com/leaflet/dist/leaflet.js"></script>
<script src="//unpkg.com/vue2-leaflet"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <vue-google-heatmap :beneficiarias="<?php echo e($beneficiarias); ?>" :aliados="<?php echo e($aliados); ?>"></vue-google-heatmap>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctiam\resources\views/management/statisticsInfo.blade.php ENDPATH**/ ?>