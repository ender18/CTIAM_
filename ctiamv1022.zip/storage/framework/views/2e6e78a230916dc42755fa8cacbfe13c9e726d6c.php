

<?php $__env->startSection('content'); ?>

  <edit-information-component :usuario="<?php echo e($usuario); ?>"></edit-information-component >

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctiam\resources\views/auth/editInformation.blade.php ENDPATH**/ ?>