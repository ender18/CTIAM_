@extends('layouts.app')

@section('content')
  <register-component :aliados="{{$aliados}}"></register-component>

@endsection
