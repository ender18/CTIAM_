<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Bienvenido - CTIAM</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/bootstrap4-toggle.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/myjs.js')); ?>" defer></script>
    <script src="https://kit.fontawesome.com/4aac046800.js" crossorigin="anonymous"></script>


    <link rel="stylesheet" href="//unpkg.com/leaflet/dist/leaflet.css" />
    <script src="//unpkg.com/leaflet/dist/leaflet.js"></script>
    <script src="//unpkg.com/vue2-leaflet"></script>
    
    <?php echo $__env->yieldContent('cssandjs'); ?>


    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Noto+Sans+TC" rel="stylesheet">

    <!-- Styles -->


    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/mycss.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap4-toggle.min.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-secondary shadow-sm  ">
            <div class="container">
              <?php if(auth()->guard()->guest()): ?>
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                  <img src="<?php echo e(asset('images/logo_ctiam.png')); ?>" alt="" class="img img-fluid">
                </a>

                <?php else: ?>
                  <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                    <img src="<?php echo e(asset('images/logo_ctiam.png')); ?>" alt="" class="img img-fluid">
                  </a>
              <?php endif; ?>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto ">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto align-items-center">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="mr-3">
                              <a class="nav-link text-white" href="<?php echo e(route('conocenos')); ?>">Conócenos</a>
                            </li>
                            <li class="mr-3">
                              <a class="nav-link text-white" href="<?php echo e(route('miembros')); ?>">Nuestros Miembros</a>
                            </li>
                            <li class="mr-3">
                              <a class="nav-link text-white" href="<?php echo e(route('fundadoras')); ?>">Fundadoras</a>
                            </li>
                            <li class="mr-3">
                              <a class="nav-link text-white" href="<?php echo e(route('focos')); ?>">Focos</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link text-white" href="<?php echo e(route('login')); ?>"><button class="btn btn-light">Inicia Sesión</button></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link text-white" href="<?php echo e(route('register')); ?>"><button class="btn btn-dark">¡Registrate!</button></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                          <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                 <span class="caret">Página principal</span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('welcome')); ?>">Inicio</a>
                                <a class="dropdown-item" href="<?php echo e(route('conocenos')); ?>">Conócenos</a>
                                <a class="dropdown-item" href="<?php echo e(route('miembros')); ?>">Nuestros Miembros</a>
                                <a class="dropdown-item" href="<?php echo e(route('fundadoras')); ?>">Fundadoras</a>
                                <a class="dropdown-item" href="<?php echo e(route('focos')); ?>">Focos</a>
                            </div>
                          </li>
                            <li class="mr-3">
                              <a class="nav-link text-white" href="<?php echo e(route('home')); ?>">Dashboard</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Cerrar sesión')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>



        <div class="py-4 bg-white">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <footer-component></footer-component>

    </div>
<!-- Footer -->
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ctiam\resources\views/layouts/app.blade.php ENDPATH**/ ?>