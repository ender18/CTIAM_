@extends('layouts.app')

@section('content')

<indexmanagement-component :contents="{{$content}}"></indexmanagement-component>

@endsection
