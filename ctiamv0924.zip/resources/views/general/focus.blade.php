@extends('layouts.app')

@section('content')

<focus-component :focus="{{$focus}}"></focus-component>


@endsection
