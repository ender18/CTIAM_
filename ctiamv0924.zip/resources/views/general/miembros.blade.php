@extends('layouts.app')

@section('content')

<members-component :members = "{{$members}}" :aliados ="{{$aliados}}" :cantidad_cursos="{{$cantidad_cursos}}"></members-component>


@endsection
