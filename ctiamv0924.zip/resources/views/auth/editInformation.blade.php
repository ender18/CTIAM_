@extends('layouts.app')

@section('content')

  <edit-information-component :usuario="{{$usuario}}"></edit-information-component >

@endsection
