<template >

  <div class="container">
    <div class="row d-flex justify-content-between">

      <div class="col-12 text-center">
        <br>
        <h2 class="border-bottom border-secondary border-secondary border-3" >
          <span class="bg-secondary text-white  pl-2 pr-2 rounded-top  border-4 ">Miembros de nuestra Red de Conocimiento</span></h2>
      </div>

      <div class="col-lg-3 col-sm-6 mt-2 d-flex justify-content-center" v-for="member in members">
        <div class="card" style="width: 18rem;">
          <img class="card-img-top img-fluid" v-bind:src="member.file" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">{{member.content}}</h5>
            <p class="card-text">{{member.content1}}</p>
            <p class="card-text"><strong>Aportes:</strong> {{member.content3}}</p>
            <a v-bind:href="member.content2" class="btn btn-primary" target="_blank">Ir al sitio web</a>
          </div>
        </div>
      </div>
    </div>
    <div class="row d-flex justify-content-center">
      <div class="col-12 text-center">
        <br>
        <h2 class="border-bottom border-secondary border-secondary border-3" >
          <span class="bg-secondary text-white  pl-2 pr-2 rounded-top  border-4 ">Aliados de nuestra Red de Conocimiento</span></h2>
      </div>
      <div class="col-8">
          <table class="table text-center">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">Nombre</th>
                  <!-- <th scope="col">Aliado desde</th> -->
                  <th scope="col">Cantidad de actividades de formación</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="aliado in aliados">
                  <th scope="row"><h5>{{aliado.last_name}} {{aliado.name}}</h5></th>
                  <!-- <th scope="row"><h5>{{aliado.created_at}}</h5></th> -->
                  <td v-for="cantidad in cantidad_cursos" v-if="aliado.id == cantidad.id_teacher"> <h5>{{cantidad.total}}</h5></td>
                </tr>
              </tbody>
            </table>
        </div>
    </div>
  </div>




</template>

<script>
export default {

  data(){

    return{



    }
  },

  props:['members', 'aliados', 'cantidad_cursos']







}
</script>

<style>
</style>
