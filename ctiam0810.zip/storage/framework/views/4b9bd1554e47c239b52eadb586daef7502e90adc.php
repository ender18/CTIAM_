


<?php $__env->startSection('content'); ?>
  <show-events-component :events_with_preferences="<?php echo e($events_with_preferences); ?>" :events_without_preferences="<?php echo e($events_without_preferences); ?>"
    
  ></show-events-component>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctiam\resources\views/beneficiary/showEvents.blade.php ENDPATH**/ ?>