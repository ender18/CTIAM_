<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Focus extends Model
{
    //
}
