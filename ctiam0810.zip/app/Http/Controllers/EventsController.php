<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Course;
use App\Focus;
use DB;
use App\User;


class EventsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
          $focos = Focus::get();
          $courses = Course::where('id_owner', auth()->user()->id)->get();
          return view('ally.manageEvents', compact('focos', 'courses'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if ($request->ajax()) {
          $msj = 'Ocurrió un error, intente de nuevo.';



          $name='';
          if($request->hasFile('file')){
            $file = $request->file('file');
            $name =time().$file->getClientOriginalName();
            $file->move(public_path().'/images/user/',$name);
          }

          $course = null;
          if ($request->id === null) {
            $course = new Course();
          }else {
            $course = Course::find($request->id);
          }

          $course->type = $this->validarString($request->type);
          $course->title = $this->validarString($request->title);
          $course->description = $this->validarString($request->description);
          $course->duration = $this->validarString($request->duration);
          $course->duration_type = $this->validarString($request->durationtext);

          $course->quota = $this->validarString($request->quota);
          $course->fecha_inicio = $this->validarString($request->fecha_inicio);
          $course->fecha_fin = $this->validarString($request->fecha_fin);
          $course->schedule = $this->validarString($request->schedule);

          $course->fecha_inicio_inscription = $this->validarString($request->fecha_inicio_inscription);
          $course->fecha_fin_inscription = $this->validarString($request->fecha_fin_inscription);
          $course->place = $this->validarString($request->place);
          $course->cost = $this->validarString($request->cost);
          $course->id_owner = auth()->user()->id;
          $course->status = $this->validarString($request->status);

          if ($name !== '' && $name !== null) {
            $course->url_image = '/images/user/'.$name;
          }

          $course->Save();

          $events = Course::where('id_owner', auth()->user()->id)->get();


          $resultado = null;
          $array = $request->focosSeleccionados;

          $fecha_hoy = date("Y-m-d H:i:s");
          $array_focos = json_decode($array);


          // Se insertan los focos del Evento
          DB::table('course_foci')->where('course_id', $course->id)->delete();
          $data = array(
          );
          foreach ($array_focos as $value) {
             array_push($data, array('course_id'=> $course->id, 'foci_id'=> $value->id, 'created_at'=> $fecha_hoy, 'updated_at'=> $fecha_hoy));
          }
          DB::table('course_foci')->insert($data);
          // Fin inserción


          $msj = 'Los cambios se guardaron correctamente.';
          return response()->json([
            'msj' => $msj,
            'events' => $events

          ], 200);
        }
    }

    public function SearchCoursesFocos(Request $request){
      if ($request->ajax()) {
        // code...
        $focos = Focus::whereIn('id' , DB::table('course_foci')->select('foci_id')->where('course_id', $request->id))->get();
        return response()->json([
          'focos' => $focos
        ], 200);
      }
    }

    public function validarString($string){
      if ($string == 'null' || $string == '') {
        return null;
      }
      return $string;
    }

    public function changeStatus(Request $request){
      if ($request->ajax()) {

        $evento = Course::find($request->id);
        $evento->status = $request->status;
        $evento->Save();
        $events = Course::where('id_owner', auth()->user()->id)->get();
        $msj = 'El evento ha cambiado su estado correctamente';
        DB::table('courses_users')
            ->where('id_course', $request->id)
            ->update(['status' => $request->status]);


        return response()->json([
          'eventos' => $events,
          'msj' => $msj
        ], 200);
      }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function show(Request $request, $id)
    {

        if ($request->ajax()) {

          $curso = Course::join('users', 'courses.id_owner', '=', 'users.id')
                  ->where('courses.id', '=' ,$id)->first();
          $focos = Focus::join('course_foci', 'foci.id', '=', 'course_foci.foci_id')->where('course_foci.course_id', '=', $id)->get();
          $students  = User::join('courses_users', 'users.id', '=', 'courses_users.id_users')->where('courses_users.id_course', '=', $id)->get();
          $array_focos = array();

          foreach ($focos as $value) {
            array_push($array_focos, ' '.$value->name);
          }


          $focos_string = implode(",", $array_focos);


            return response()->json([
              'course' => $curso,
              'focos' => $focos_string,
              'students' => $students
            ], 200);
        }
    }

    public function finishCourse(Request $request){
      $id = $request->id_course;

      $curso = Course::join('users', 'courses.id_owner', '=', 'users.id')
              ->where('courses.id', '=' ,$id)->first();
      $focos = Focus::join('course_foci', 'foci.id', '=', 'course_foci.foci_id')->where('course_foci.course_id', '=', $id)->get();
      $students  = User::join('courses_users', 'users.id', '=', 'courses_users.id_users')->where('courses_users.id_course', '=', $id)->get();
      $array_focos = array();

      foreach ($focos as $value) {
        array_push($array_focos, ' '.$value->name);
      }

      $focos_string = implode(",", $array_focos);

      return view('management.finishCourse', compact('curso', 'students', 'focos_string', 'id'));
    }

    public function finishCourseLast(Request $request){
      if ($request->ajax()) {
        // $request->id_course
        // $request->id_aproved
        // $request->id_no_aproved

        DB::table('courses_users')
              ->whereIn('id', $request->id_aproved)
              ->update(['status' => 'Aprobado']);



        DB::table('courses_users')
              ->whereIn('id', $request->id_no_aproved)
              ->update(['status' => 'No Aprobado']);

        $course = Course::find($request->id_course);
        $course->status = 'Finalizado';
        $course->save();



        $students  = DB::table('courses_users')->join('users', 'users.id', '=', 'courses_users.id_users')->where('courses_users.id_course', '=', $request->id_course)->get();

        return response()->json([
          'msj' => 'El curso se ha finalizado correctamente',
          'students' => $students
        ],200);
      }


    }

    public function showEvents(Request $request)
    {
      $fecha_hoy = date("Y-m-d H:i:s");

        $my_courses = DB::table('courses_users')->select('id_course')->where('id_users', '=', auth()->user()->id)->get();

        // Filtro de los cursos donde ya estoy matriculado
        $arrayMyCourses = array();
        foreach ($my_courses as  $value) {
          array_push($arrayMyCourses, $value->id_course);
        }

        $all_courses = Course::where('status', '=', 'Publicado')->get();
        $matriculados = DB::table('courses_users')
                 ->select('id_course', DB::raw('count(id_course) as total'))
                 ->groupBy('id_course')
                 ->get();

        $lista_cupo_full = array();
        foreach ($all_courses as  $value) {
            foreach ($matriculados as  $value1) {
                if ($value->id == $value1->id_course) {
                      if ($value->quota < $value1->total) {
                        array_push($lista_cupo_full, $value->id);
                      }
                }
            }
        }



        $events_with_preferences = Course::select('courses.id', 'courses.title', 'courses.description', 'courses.type' ,'courses.url_image')
              ->join('course_foci', 'courses.id', '=', 'course_foci.course_id')
              ->whereIn('course_foci.foci_id', DB::table('foci_user')->select('foci_user.foci_id')->where('foci_user.user_id', auth()->user()->id))
              ->whereNotIn('courses.id', $arrayMyCourses)
              ->whereNotIn('courses.id', $lista_cupo_full)
              ->where('courses.fecha_inicio_inscription', '<', $fecha_hoy)
              ->where('fecha_fin_inscription', '>', $fecha_hoy)
              ->where('courses.status', '=', 'Publicado')
              ->distinct('courses.id')->get();

        $array = array();
        foreach ($events_with_preferences as  $value) {
          array_push($array, $value->id);
        }



        $events_without_preferences = Course::select('courses.id', 'courses.title', 'courses.type' , 'courses.description', 'courses.url_image')
              ->whereNotIn('courses.id', $array)
              ->whereNotIn('courses.id', $arrayMyCourses)
              ->whereNotIn('courses.id', $lista_cupo_full)
              ->where('courses.fecha_inicio_inscription', '<', $fecha_hoy)
              ->where('fecha_fin_inscription', '>', $fecha_hoy)
              ->where('courses.status', '=', 'Publicado')
              ->distinct('courses.id')->get();




        return view('beneficiary.showEvents', compact('events_with_preferences', 'events_without_preferences'));
    }

    public function suscribe(Request $request){
      if ($request->ajax()) {
        $msj = '';
        $status = '';

        $curso = Course::find($request->id);
        $matriculados1 = count(DB::table('courses_users')->where('id_course', $request->id)->get());

        if ($curso->quota > $matriculados1) {
          $fecha_hoy = date("Y-m-d H:i:s");
          DB::table('courses_users')->insert(
            ['id_users' => auth()->user()->id, 'id_course' => $request->id, 'status' => 'Matriculado', 'created_at'=> $fecha_hoy, 'updated_at'=> $fecha_hoy]
          );
          $msj = 'Se ha inscrito en la actividad "'.$curso->title.'" satisfactoriamente. ¿Desea ver más actividades disponibles o ver actividades matriculadas?';
          $status = 'success';
        }else {
          $msj = 'No se ha podido inscribir en el curso "'.$curso->title.'" ha excedido el cupo maximo';
          $status = '';
        }


        // Actualizar mis cursos
        $fecha_hoy = date("Y-m-d H:i:s");
          $my_courses = DB::table('courses_users')->select('id_course')->where('id_users', '=', auth()->user()->id)->get();

          // Filtro de los cursos donde ya estoy matriculado
          $arrayMyCourses = array();
          foreach ($my_courses as  $value) {
            array_push($arrayMyCourses, $value->id_course);
          }

          $all_courses = Course::where('status', '=', 'Publicado')->get();
          $matriculados = DB::table('courses_users')
                   ->select('id_course', DB::raw('count(id_course) as total'))
                   ->groupBy('id_course')
                   ->get();

          $lista_cupo_full = array();
          foreach ($all_courses as  $value) {
              foreach ($matriculados as  $value1) {
                  if ($value->id == $value1->id_course) {
                        if ($value->quota < $value1->total) {
                          array_push($lista_cupo_full, $value->id);
                        }
                  }
              }
          }

          $events_with_preferences = Course::select('courses.id', 'courses.title', 'courses.description', 'courses.type' ,'courses.url_image')
                ->join('course_foci', 'courses.id', '=', 'course_foci.course_id')
                ->whereIn('course_foci.foci_id', DB::table('foci_user')->select('foci_user.foci_id')->where('foci_user.user_id', auth()->user()->id))
                ->whereNotIn('courses.id', $arrayMyCourses)
                ->whereNotIn('courses.id', $lista_cupo_full)
                ->where('courses.fecha_inicio_inscription', '<', $fecha_hoy)
                ->where('fecha_fin_inscription', '>', $fecha_hoy)
                ->where('courses.status', '=', 'Publicado')
                ->distinct('courses.id')->get();

          $array = array();
          foreach ($events_with_preferences as  $value) {
            array_push($array, $value->id);
          }

          $events_without_preferences = Course::select('courses.id', 'courses.title', 'courses.type' , 'courses.description', 'courses.url_image')
                ->whereNotIn('courses.id', $array)
                ->whereNotIn('courses.id', $arrayMyCourses)
                ->whereNotIn('courses.id', $lista_cupo_full)
                ->where('courses.fecha_inicio_inscription', '<', $fecha_hoy)
                ->where('fecha_fin_inscription', '>', $fecha_hoy)
                ->where('courses.status', '=', 'Publicado')
                ->distinct('courses.id')->get();


        return response()->json([
          'msj' => $msj,
          'status' => $status,
          'events_with_preferences' => $events_with_preferences,
          'events_without_preferences' => $events_without_preferences

        ], 200);
      }
    }

    public function showMyEvents(Request $request){

      $my_courses = Course::join('courses_users', 'courses.id', '=', 'courses_users.id_course')->where('courses_users.id_users', auth()->user()->id)->get();

      return view('beneficiary.showMyEvents', compact('my_courses'));
    }

    public function cancelCourse(Request $request){
      if ($request->ajax()) {
        $msj = '';
        DB::table('courses_users')->where('id', $request->id)->update(['status' => 'Cancelado']);
        // code...
        $my_courses = Course::join('courses_users', 'courses.id', '=', 'courses_users.id_course')->where('courses_users.id_users', auth()->user()->id)->get();

        return response()->json([
          'msj' => $msj,
          'courses' => $my_courses
        ],200);
      }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id, Request $request)
    {
        if ($request->ajax()) {
          $course = Course::find($id);
          $msj = $course->title.' se ha eliminado satisfactoriamente.';
          DB::table('course_foci')->where('course_id', $course->id)->delete();
          $course->delete();

          $eventos = Course::where('id_owner', auth()->user()->id)->get();
          return response()->json([
            'eventos' => $eventos,
            'msj' => $msj
          ],200);
        }
    }
}
