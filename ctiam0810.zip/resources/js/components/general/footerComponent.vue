<template >

  <footer class="pt-4 bg-secondary shadow-sm">
    <!-- Footer Links -->
    <div class="container text-center text-light text-md-left ">

      <!-- Grid row -->
      <div class="row">

        <!-- Grid column -->
        <div class="col-md-6 mt-md-0 mt-3">

          <!-- Content -->
          <h5 class="text-uppercase "><strong>Descripción de nuestra red de conocimiento CTIAM</strong></h5>
          <p>{{description}}</p>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none pb-3">

        <!-- Grid column -->
        <div class="col-md-3 mb-md-0 mb-3">

          <!-- Links -->
          <h5 class="text-uppercase"><strong>CONTACTO</strong></h5>

          <ul class="list-unstyled">
            <li>
              <span>Teléfono: {{phone}}</span>
            </li>
            <li>
              <span >Correo electrónico: <a class="text-light" href="#">{{email}}</a> </span>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-3 mb-md-0 mb-3">

          <!-- Links -->
          <h5 class="text-uppercase"><strong>REDES SOCIALES</strong></h5>

          <ul class="list-unstyled">
            <li>
              <i class="fab fa-twitter fa-2x "></i><span> {{twitter}}</span>
            </li>
            <li>
              <i class="fab fa-facebook-square fa-2x"></i><span> {{facebook}}</span>
            </li>
            <li>
              <i class="fab fa-instagram fa-2x"></i> <span> {{instagram}}</span>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

      </div>
      <!-- Grid row -->

    </div>
    <!-- Footer Links -->

    <!-- Copyright -->
    <div class="footer-copyright text-center py-3 text-white bg-dark" >© 2020 Copyright:
      <a class="text-light" href="https://ww2.ufps.edu.co/"> UFPS</a>
    </div>
    <!-- Copyright -->

  </footer>

</template>

<script>
export default {

  data(){
    return {
      description : '',
      phone : '',
      email : '',
      twitter : '',
      facebook : '',
      instagram : ''
    }
  },


  created(){

    axios.post('/getInfoFooter',{
    })
    .then(response => {
      this.description = response.data.description;
      this.phone = response.data.phone;
      this.email = response.data.email;
      this.twitter = response.data.twitter;
      this.facebook = response.data.facebook;
      this.instagram= response.data.instagram;

    }).catch(function (error){
      console.log(error);
    });
  }


  }
</script>

<style lang="css" scoped>
</style>
