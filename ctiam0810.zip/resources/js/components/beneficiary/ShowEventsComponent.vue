<template >

  <div class="container">
    <div class="row">
      <div id="msj" v-show="a"  class="col-12">
        <div class="alert alert-success" role="alert">
          {{msj}}
        </div>
      </div>
      <div class="col-12" v-if="events_with_preferences1.length == 0 && events_without_preferences1.length == 0">
        <h4>No hay ninguna actividad de formación para mostrar.</h4>
        <hr>
      </div>
      <div class="col-12" v-if="events_with_preferences1.length >0">
        <h4>Actividades de formación recomendadas para ti</h4>
        <hr>
      </div>
      <div class="col-12" >
        <div class="row">
          <div class="col-sm-6 col-md-6 col-lg-3 mt-2" v-for="evento in events_with_preferences1">
            <div class="card">
              <a  v-on:click="openShowModal(evento.id)"><img class="card-img-top img-fluid" v-bind:src="evento.url_image" alt=""></a>
              <div class="card-body text-center">
                <h5 class="card-tittle">{{evento.title}}</h5>
                <p class="card-text">Tipo: {{evento.type}}</p>
                <button type="button" class="btn btn-dark txt-white" v-on:click="openShowModal(evento.id)">Ver Info</button>
                <button type="button" class="btn btn-secondary btn-lg" v-on:click="suscribe(evento.id)">Inscribirme</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-12" v-if="events_with_preferences1.length == 0 && events_without_preferences1.length > 0">
        <br>
        <h4>Actividades de formación</h4>
        <hr>
      </div>
      <div class="col-12" v-if="events_with_preferences1.length > 0 && events_without_preferences1.length > 0">
        <br>
        <h4>Otras actividades de formación</h4>
        <hr>
      </div>
      <div class="col-12" >
        <div class="row">
          <div class="col-sm-6 col-md-6 col-lg-3 mt-2" v-for="evento1 in events_without_preferences1">
            <div class="card">
              <a  v-on:click="openShowModal(evento1.id)"><img class="card-img-top img-fluid" v-bind:src="evento1.url_image" alt=""></a>
              <div class="card-body text-center">
                <h5 class="card-tittle">{{evento1.title}}</h5>
                <p class="card-text">Tipo: {{evento1.type}}</p>
                <button type="button" class="btn btn-dark txt-white" v-on:click="openShowModal(evento1.id)">Ver Info</button>
                <button type="button" class="btn btn-secondary btn-lg" v-on:click="suscribe(evento1.id)">Inscribirme</button>
              </div>
            </div>
          </div>
        </div>
      </div>


    </div>

    <div class="modal fade" id="modalShow" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="container">
              <div class="row">
                <div class="col-6">

                  <img v-bind:src="url_image"  class="img img-fluid" alt="">

                </div>
                <div class="col-6">
                  <h1>{{title}}</h1>
                  <p>{{description}}</p>
                  <p><strong>Tipo: </strong>{{type}}</p>
                  <p><strong>Foco(s): </strong>{{focos}}</p>
                  <p><strong>Duración: </strong>{{duration}} {{duration_type}}</p>
                  <p><strong>Cupo máximo: </strong>{{quota}} personas</p>
                  <p><strong>Fecha de Inicio: </strong>{{fecha_inicio}}</p>
                  <p><strong>Fecha Fin: </strong>{{fecha_fin}}</p>
                  <p><strong>Hoario: </strong>{{schedule}}</p>
                  <p><strong>Lugar: </strong>{{place}}</p>
                  <p><strong>Encargado: </strong>{{name_owner}}</p>
                  <p><strong>Contacto: </strong>{{email_owner}}</p>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary btn-lg" v-on:click="suscribe(id_course)">Inscribirme</button>
            <button type="button" class="btn btn-dark txt-white" data-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    </div>

    <div class="modal fade" id="modalSuscribe" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog " role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="container">
              <div class="row">
                <div class="col-12">
                  <h5>{{msj}}</h5>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-dark txt-white" data-dismiss="modal">Ver más actividades de formación</button>
             <a href="/myEvents" class="btn btn-secondary">ir a Mis Actividades</a>
          </div>
        </div>
      </div>
    </div>

  </div>


</template>

<script>
export default {

  data(){

    return {
      events_with_preferences1 : this.events_with_preferences,
      events_without_preferences1 : this.events_without_preferences,

      a: false,
      msj: '',

      // Elementos del curso a mostrar
      id_course: '',
      title : '',
      type : '',
      description : '',
      duration : '',
      duration_type : '',
      url_image : '',
      quota : '',
      fecha_inicio : '',
      fecha_fin : '',
      place : '',
      name_owner : '',
      email_owner : '',
      focos : '',
      schedule : ''




    }


  },

props:[ 'events_with_preferences', 'events_without_preferences'],

methods:{
      openShowModal: function(id){
        this.id_course = id;
        axios.get('/manageEvents/'+id)
        .then(response => {
          this.title = response.data.course.title;
          this.type = response.data.course.type;
          this.description = response.data.course.description;
          this.duration = response.data.course.duration;
          this.duration_type = response.data.course.duration_type;
          this.url_image = response.data.course.url_image;
          this.quota = response.data.course.quota;
          this.fecha_inicio = response.data.course.fecha_inicio;
          this.fecha_fin = response.data.course.fecha_fin;
          this.place = response.data.course.place;
          this.name_owner= response.data.course.name;
          this.email_owner= response.data.course.email;
          this.schedule = response.data.course.schedule;
          this.focos = response.data.focos;
           $('#modalShow').modal('show');

        }).catch(function (error){
          console.log(error);
        });

      },

      suscribe: function(id){
        axios.post('/manageEvents/suscribe', { id: id})
        .then(response =>{
          this.msj = response.data.msj;
          this.events_with_preferences1 = response.data.events_with_preferences;
          this.events_without_preferences1 = response.data.events_without_preferences;
          $('#modalShow').modal('hide');
          $('#modalSuscribe').modal('show');



        }).catch(function(error){
          console.log(error);
        });
      },


      showMessage: function(msj, status){
        this.msj = msj;
        this.a = true;
        $("#msj").fadeIn(500);
        setTimeout(function(){
            $("#msj").fadeOut();
            this.a = false;
        }, 2000);
      },



}




}
</script>

<style>
</style>
