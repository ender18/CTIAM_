<template >



    <div class="container">
      <div class="row">
        <div id="msj" v-show="a"  class="col-12">
          <div class="alert alert-success" role="alert">
            {{msj}}
          </div>
        </div>
        <div class="col-12" v-if="my_courses1.length == 0">
          <h2>No has matriculado ninguna actividad de formación, mira <a href="/showEvents">aquí</a>  las que tenemos dispobles para ti</h2>
        </div>
        <div class="col-12" v-if="my_courses1.length > 0">
          <h2>Mis Activiades de formación matriculadas</h2>

        </div>
        <div class="col-12" v-if="my_courses1.length > 0">
          <table class="table" >
            <thead>
              <tr>
                <th scope="col"></th>
                <th scope="col">Título</th>
                <th scope="col">Tipo</th>
                <th scope="col">Estado</th>
                <th scope="col">Opciones</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="my_course in my_courses1">
                <td><img v-bind:src="my_course.url_image" alt="" class="img img-fluid" style="width: 50px"></td>
                <th scope="row" >{{my_course.title}}</th>
                <td>{{my_course.type}}</td>
                <td>{{my_course.status}}</td>
                <td><button class="btn btn-secondary" type="button" name="button" v-on:click="openShowModal(my_course.id_course)">Ver <i class="far fa-question-circle"></i></button> <button class="btn btn-danger" type="button" name="button"
                  v-if="my_course.status == 'Matriculado' || my_course.status == 'En curso'" v-on:click="confirmCancelCourse(my_course.id)">Cancelar <i class="far fa-times-circle"></i></button>
                </td>

              </tr>
            </tbody>
          </table>
        </div>

        <div class="modal fade" id="modalShow" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div class="container">
                  <div class="row">
                    <div class="col-6">

                      <img v-bind:src="url_image"  class="img img-fluid" alt="">

                    </div>
                    <div class="col-6">
                      <h1>{{title}}</h1>
                      <p>{{description}}</p>
                      <p><strong>Tipo: </strong>{{type}}</p>
                      <p><strong>Foco(s): </strong>{{focos}}</p>
                      <p><strong>Duración: </strong>{{duration}} {{duration_type}}</p>
                      <p><strong>Cupo máximo: </strong>{{quota}} personas</p>
                      <p><strong>Fecha de Inicio: </strong>{{fecha_inicio}}</p>
                      <p><strong>Fecha Fin: </strong>{{fecha_fin}}</p>
                      <p><strong>Horario: </strong>{{schedule}}</p>

                      <p><strong>Lugar: </strong>{{place}}</p>
                      <p><strong>Encargado: </strong>{{name_owner}}</p>
                      <p><strong>Contacto: </strong>{{email_owner}}</p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-dark txt-white" data-dismiss="modal">Cerrar</button>
              </div>
            </div>
          </div>
        </div>

        <div class="modal fade" id="confirm_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">¿Seguro que desea cancelar este curso?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                      <p class="txt-danger">Despúes de cancelado el curso no podrá volver a matricularlo, ¿Estas seguro?</p>

              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-success" data-dismiss="modal">No</button>
                <button type="button" class="btn btn-danger" v-on:click="cancelCourse()">Si</button>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>


</template>

<script>
export default {

  data(){
    return {

      my_courses1 : this.my_courses,
      msj: '',
      a: false,

      id_matricula: '',
      id_course: '',
      title : '',
      type : '',
      description : '',
      duration : '',
      duration_type : '',
      url_image : '',
      quota : '',
      fecha_inicio : '',
      fecha_fin : '',
      place : '',
      name_owner : '',
      email_owner : '',
      focos : '',
      schedule : ''

    }
  },



props:['my_courses'],

methods:{
    openShowModal: function(id){
      this.id_course = id;
      axios.get('/manageEvents/'+id)
      .then(response => {
        this.title = response.data.course.title;
        this.type = response.data.course.type;
        this.description = response.data.course.description;
        this.duration = response.data.course.duration;
        this.duration_type = response.data.course.duration_type;
        this.url_image = response.data.course.url_image;
        this.quota = response.data.course.quota;
        this.fecha_inicio = response.data.course.fecha_inicio;
        this.fecha_fin = response.data.course.fecha_fin;
        this.place = response.data.course.place;
        this.name_owner= response.data.course.name;
        this.email_owner= response.data.course.email;
        this.schedule= response.data.course.schedule;
        this.focos = response.data.focos;
         $('#modalShow').modal('show');
      }).catch(function (error){
        console.log(error);
      });

    },

    confirmCancelCourse: function(id){
      this.id_matricula = id;
        $('#confirm_modal').modal('show');


    },

    cancelCourse: function(){
      axios.post('/myEvents/cancelCourse',{ id: this.id_matricula})
      .then(response => {
        this.my_courses1 = response.data.courses;
        $('#confirm_modal').modal('hide');




      }).catch(function (error){
        console.log(error);
      });


    },

    showMessage: function(msj, status){
      this.msj = msj;
      this.a = true;
      $("#msj").fadeIn(500);
      setTimeout(function(){
          $("#msj").fadeOut();
          this.a = false;
      }, 2000);
    },

    probarToggle: function(id_toggle){
      var status = document.getElementById(id_toggle).checked;
      console.log(status);
    }

  }
}
</script>

<style>
</style>
