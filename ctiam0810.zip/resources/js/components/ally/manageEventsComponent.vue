<template>

  <div class="container">
    <div class="row">
      <div id="msj" v-show="a"  class="col-12">
        <div class="alert alert-success" role="alert">
          {{msj}}
        </div>
      </div>
      <div class="col-10">
        <h2>Administración de Actividades de formación y capacitación</h2>
      </div>
      <div class="col-2">
        <button class="btn btn-primary " type="button" name="button" v-on:click="openModalContent(null)"><i class="fas fa-plus" ></i> Nueva Actividad</button>

      </div>
      <div class="col-12">
        <table class="table">
          <thead>
            <tr>
              <th scope="col">Titulo</th>
              <th scope="col">Descripción</th>
              <th scope="col">Estado</th>
              <th scope="col"></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="foco in eventos">
              <th scope="row">{{foco.title}}</th>
              <td >{{foco.description}}</td>
              <td v-if="foco.status === 'Borrador'"><p class="bg-primary text-white text-center">{{foco.status}}</p></td>
              <td v-if="foco.status === 'Publicado'"><p class="bg-dark text-white text-center">{{foco.status}}</p></td>
              <td v-if="foco.status === 'En curso'"><p class="bg-warning text-center">{{foco.status}}</p></td>
              <td v-if="foco.status === 'Finalizado'"><p class="bg-success text-white text-center">{{foco.status}}</p></td>
              <td v-if="foco.status === 'Cancelado'"><p class="bg-danger text-white text-center">{{foco.status}}</p></td>
              <td>
                <div class="btn-group">
                  <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Opciones
                  </button>
                <div class="dropdown-menu">
                  <a class="dropdown-item" href="#" v-on:click="openShowModal(foco.id)">Ver</a>
                  <div class="dropdown-divider"></div>
                  <h6 class="dropdown-header" v-if="foco.status != 'Cancelado' && foco.status != 'Finalizado'">Cambiar estado</h6>
                  <a class="dropdown-item" href="#" v-if="foco.status === 'Borrador'" v-on:click="changeStatus(foco.id, 'Publicado')">Publicar</a>
                  <a class="dropdown-item" href="#" v-if="foco.status === 'Publicado'" v-on:click="changeStatus(foco.id, 'En curso')">Iniciar</a>
                  <a class="dropdown-item" v-bind:href="'/finishCourse?id_course='+foco.id" v-if="foco.status === 'En curso'">Finalizar</a>
                  <a class="dropdown-item" href="#" v-if="foco.status != 'Cancelado' && foco.status != 'Finalizado'" v-on:click="changeStatus(foco.id, 'Cancelado')">Cancelar</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="#" v-if="foco.status === 'Borrador'" v-on:click="openModalContent(foco.id)" >Editar</a>
                  <a class="dropdown-item" href="#" v-if="foco.status === 'Borrador'" v-on:click="deleteEvent(foco.id)">Eliminar</a>
                </div>
              </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Modal Foco -->
    <div class="modal fade" id="modalFocus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Editar / Agregar Actividades</h5>
          </div>
          <div class="modal-body">
            <form class="form-group" v-on:submit.prevent="addChangeFocus">
              <div class="row">
                <div class="col-12" >
                  <img v-bind:src="imgMiniatura" alt="" class="img img-fluid">
                </div>
                <div class="col-6 form-group">
                  <label>Tipo</label>
                  <select class="form-control" v-model="type">
                    <option>Curso</option>
                    <option>Diplomado</option>
                    <option>Taller</option>
                    <option>Capacitación</option>
                  </select>
                </div>
                <div class="col-6 form-group">
                  <label for="">Título</label>
                  <input class="form-control" type="text" name="" value="" v-model="title">
                </div>

                <div class="col-12 form-group">
                  <label for="">Descripción</label>
                  <textarea class="form-control" rows="3" v-model="description"></textarea>
                </div>

                <div class="col-4 form-group">
                  <label for="">Duración</label>
                  <input class="form-control" type="number" name="" value="" v-model="duration">
                </div>
                <div class="col-4 form-group">
                  <label>-</label>
                  <select class="form-control" v-model="durationtext">
                    <option>Horas</option>
                    <option>Semanas</option>
                    <option>Meses</option>
                    <option>Años</option>
                  </select>
                </div>
                <div class="col-4 form-group">
                  <label for="">Cupo máximo</label>
                  <input class="form-control" type="number" name="" value="" v-model="quota">
                </div>
                <div class="col-6 form-group">
                  <label for="">Fecha de inicio</label>
                  <input class="form-control" type="date" name="" value="" v-model="fecha_inicio">
                </div>
                <div class="col-6 form-group">
                  <label for="">Fecha de finalización</label>
                  <input class="form-control" type="date" name="" value="" v-model="fecha_fin">
                </div>
                <div class="col-12 form-group">
                  <label for="">Horario</label>
                  <input class="form-control" type="text" name="" value="" v-model="schedule">
                </div>
                <div class="col-6 form-group">
                  <label for="">Fecha inicio de inscripción</label>
                  <input class="form-control" type="date" name="" value="" v-model="fecha_inicio_inscription">
                </div>
                <div class="col-6 form-group">
                  <label for="">Fecha limite de inscripción</label>
                  <input class="form-control" type="date" name="" value="" v-model="fecha_fin_inscription">
                </div>
                <div class="col-6 form-group">
                  <label for="">Lugar de reuniones</label>
                  <input class="form-control" type="text" name="" value="" v-model="place">
                </div>
                <div class="col-6 form-group">
                  <label for="">Costo ($)</label>
                  <input class="form-control" type="number" name="" value="" v-model="cost">
                </div>
                <div class="col-12 form-group">
                  <label for="exampleFormControlSelect1">Foco(s) al que pertenece</label>
                  <select class="form-control" id="selectFocos" v-model="selectFocus">
                    <option value="">Selecione uno o varios focos...</option>
                    <option v-for="foco in focos1" v-bind:value="foco.id">{{foco.name}}</option>
                  </select>
                </div>

                <div class="col-4 form-group" v-for="focoSelected in focosSelected">
                  <div class="input-group">
                    <!-- <input type="text" class="form-control" id="validationDefaultUsername" placeholder="Username" aria-describedby="inputGroupPrepend2" required> -->
                    <p class="form-control">{{focoSelected.name}}</p>
                    <button class="btn btn-danger" type="button" name="button" v-on:click="borrarFoco(focoSelected.id)">
                      <div class="input-group-prepend">
                        <i class="far fa-trash-alt"></i>
                      </div>
                    </button>
                  </div>
                </div>
                <div class="col-12">
                  <hr>
                </div>
                <div class="col-8">
                  <label for="">Imagen / Archivo</label>
                  <input type="file" id="file" @change="obtenerFile" class="form-control-file" name="file">
                </div>
              </div>

              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" v-on:click="closeModalContent()">Cerrar</button>
                <button type="submit" class="btn btn-primary">Guardar Cambios</button>
              </div>

            </form>
          </div>
        </div>
      </div>
    </div>

    <!-- modal Finalizar  -->
    <div class="modal fade" id="modalShow" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="container">
              <div class="row">
                <div class="col-6">
                  <img v-bind:src="view_url_image"  class="img img-fluid" alt="">
                </div>
                <div class="col-6">
                  <h1>{{view_title}}</h1>
                  <p>{{view_description}}</p>
                  <p><strong>Estado: </strong>{{view_status}}</p>
                  <p><strong>Tipo: </strong>{{view_type}}</p>
                  <p><strong>Foco(s): </strong>{{view_focos}}</p>
                  <p><strong>Duración: </strong>{{view_duration}} {{view_duration_type}}</p>
                  <p><strong>Cupo máximo: </strong>{{view_quota}} personas</p>
                  <p><strong>Fecha de Inicio: </strong>{{view_fecha_inicio}}</p>
                  <p><strong>Fecha Fin: </strong>{{view_fecha_fin}}</p>
                  <p><strong>Horario: </strong>{{view_schedule}}</p>
                  <p><strong>Lugar: </strong>{{view_place}}</p>
                  <p><strong>Encargado: </strong>{{view_name_owner}}</p>
                  <p><strong>Contacto: </strong>{{view_email_owner}}</p>
                </div>
              </div>
              <div class="row" v-if="students.length > 0">
                <div class="col-12">
                  <hr>
                  <h4>Beneficiarias del curso - {{students.length}}</h4>
                </div>
                <div class="col-12">
                  <table class="table">
                      <thead class="thead-dark">
                        <tr>
                          <th scope="col">Nombre</th>
                          <th scope="col">Email</th>
                          <th scope="col">Telefono</th>
                          <th scope="col">Dirección</th>
                          <th scope="col">Estado</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr v-for="student in students">
                          <th scope="row">{{student.last_name}} {{student.name}}</th>
                          <td>{{student.email}}</td>
                          <td>{{student.phone}}</td>
                          <td>{{student.adress}} {{student.neighborhood}}</td>
                          <td>{{student.status}}</td>
                        </tr>
                      </tbody>
                    </table>

                </div>

              </div>
              <div class="row" v-if="students.length == 0">
                <div class="col-12">
                  <hr>
                  <h4>No hay ninguna beneficiaria matriculada.</h4>
                </div>

              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-dark txt-white" data-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    </div>



  </div>

</template>

<script>
export default {

  data(){
    return {
      eventos : this.courses,
      imgMiniatura : '',
      id: '',
      name: '',
      description: '',
      file: '',
      a: false,
      msj: '',
      focos1 : this.focos,
      focosSelected: [],
      focosArray: [],
      selectFocus : '',

// Modal Edit course
      id : '', 
      type : '',
      title : '',
      description: '',
      duration : '',
      durationtext : 'Horas',
      focus : [],
      quota : '',
      fecha_inicio : '2018-02-27T21:10',
      fecha_fin : '',
      fecha_inicio_inscription : '',
      fecha_fin_inscription : '',
      place : '',
      cost : '',
      id_owner : '', 
      status : '',
      schedule: '',

      // Elementos del curso
      view_id_course: '',
      view_title : '',
      view_type : '',
      view_description : '',
      view_duration : '',
      view_duration_type : '',
      view_url_image : '',
      view_quota : '',
      view_fecha_inicio : '',
      view_fecha_fin : '',
      view_place : '',
      view_name_owner : '',
      view_email_owner : '',
      view_focos : '',
      view_status : '',
      students: ''



    }

  },



  props:['focos', 'courses'],

  methods:{

    openShowModal: function(id){
      this.id_course = id;
      axios.get('/manageEvents/'+id)
      .then(response => {
        this.view_title = response.data.course.title;
        this.view_type = response.data.course.type;
        this.view_description = response.data.course.description;
        this.view_duration = response.data.course.duration;
        this.view_duration_type = response.data.course.duration_type;
        this.view_url_image = response.data.course.url_image;
        this.view_quota = response.data.course.quota;
        this.view_fecha_inicio = response.data.course.fecha_inicio;
        this.view_fecha_fin = response.data.course.fecha_fin;
        this.view_place = response.data.course.place;
        this.view_name_owner= response.data.course.name;
        this.view_email_owner= response.data.course.email;
        this.view_focos = response.data.focos;
        this.view_status = response.data.course.status;
        this.students = response.data.students;
        this.view_schedule = response.data.course.schedule;

         $('#modalShow').modal('show');

      }).catch(function (error){
        console.log(error);
      });

    },

    addChangeFocus: function(){

      let formData = new FormData();
      formData.append('id', this.id);
      formData.append('type', this.type);
      formData.append('title', this.title);
      formData.append('description', this.description);
      formData.append('duration', this.duration);
      formData.append('durationtext', this.durationtext);
      formData.append('quota', this.quota);
      formData.append('fecha_inicio', this.fecha_inicio);
      formData.append('fecha_fin', this.fecha_fin);
      formData.append('fecha_inicio_inscription', this.fecha_inicio_inscription);
      formData.append('fecha_fin_inscription', this.fecha_fin_inscription);
      formData.append('place', this.place);
      formData.append('cost', this.cost);
      formData.append('status', this.status);
      formData.append('file', this.file);
      formData.append('schedule', this.schedule);
      var focosSeleccionados = JSON.stringify(this.focosSelected);
      formData.append('focosSeleccionados', focosSeleccionados);

      console.log(this.focosArray);
      axios.post('/manageEvents',  formData

      ).then(response => {
         // this.focos1 = response.data.focos;
         $('#modalFocus').modal('hide');
         $('#file').val('');
         this.showMessage(response.data.msj);
         this.eventos = response.data.events;
         console.log(response.data.msj);
      }).catch(function (error){
        console.log(error);
      });


    },
    eraseContent(id){
      axios.delete('/manage_focus/'+id)
      .then(response => {
         this.focos1 = response.data.focos;
         $('#file').val('');
         this.showMessage(response.data.msj);
      }).catch(function (error){
        console.log(error);
      });

    },

    openModalContent: function(id){
      if (id== null) {
        this.schedule = '';
        this.description = '';
        this.imgMiniatura = '';
        this.status = 'Borrador';
        this.id = '';
        this.type = '';
        this.title = '';
        this.description = '';
        this.duration = '';
        this.durationtext = '';
        this.quota = '';
        this.fecha_inicio = '';
        this.fecha_fin = '';
        this.fecha_inicio_inscription = '';
        this.fecha_fin_inscription = '';
        this.place = '';
        this.cost = '';
        this.focosSelected = '';
        this.focosSelected = [];
        this.file = '';

      }else {
        var elemento = this.buscarElemento(id, this.eventos );

        axios.post('manageEvents/SearchCoursesFocos',{
          id : id
        })
        .then(response => {
          this.focosSelected = response.data.focos;
          console.log(response.data.focos);
        }).catch(function (error){
          console.log(error);
        });

        this.id = elemento.id;
        this.type = elemento.type;
        this.title = elemento.title;
        this.description = elemento.description;
        this.duration = elemento.duration;
        this.durationtext = elemento.duration_type;
        this.quota = elemento.quota;
        this.fecha_inicio = this.convertDate(elemento.fecha_inicio);
        this.fecha_fin = this.convertDate(elemento.fecha_fin);
        this.fecha_inicio_inscription = this.convertDate(elemento.fecha_inicio_inscription);
        this.fecha_fin_inscription = this.convertDate(elemento.fecha_fin_inscription);
        this.place = elemento.place;
        this.cost = elemento.cost;
        this.status = elemento.status;
        this.imgMiniatura = elemento.url_image;
        this.file = null;
        this.schedule = elemento.schedule;

        // var focosSeleccionados = JSON.stringify(this.focosSelected);
      }


      $('#modalFocus').modal('show');
    },

    deleteEvent : function(id){
      axios.delete('/manageEvents/'+id)
      .then(response => {
         this.eventos  = response.data.eventos;
         this.showMessage(response.data.msj);
      }).catch(function (error){
        console.log(error);
      });
    },

    changeStatus: function(id, status){
      axios.post('/manageEvents/changeStatus', {
        id: id , status : status
      }).then(response => {
        this.eventos  = response.data.eventos;
        this.showMessage(response.data.msj);
      }).catch(function (error){

      });
    },

    openModalFinalCourse: function(id){

      axios.get('/manageEvents/'+id)
      .then(response => {
        this.students = response.data.students;
         $('#toggle-contacto').bootstrapToggle();
         this.$forceUpdate();
         $('#studentsCourse').modal('show');

      }).catch(function (error){
        console.log(error);
      });





    },


    buscarElemento: function(id, array){
      var self = this;
      var elemento = null;
      (array).forEach(function(element) {
        if (element.id == id) {
          elemento =  element;
        }
      });
      return elemento;

    },

    existeFoco: function(id){
      var self = this;
      var elemento = null;
      (self.focosSelected).forEach(function(element) {
        if (element.id == id) {
          elemento = element;
        }
      });
      if (elemento === null) {
        return false;
      }
      return true;
    },

    borrarFoco: function(id){
      var self = this;
      var contador = 0;

      for (var i = 0; i < (self.focosSelected).length; i++) {
        if (self.focosSelected[i].id == id){
          break;
        }
      contador = i;
      }
      self.focosSelected.splice(contador, 1);
    },

    closeModalContent(){
      $('#file').val('');
      $('#modalFocus').modal('hide');
    },

    obtenerFile(e){
      let file = e.target.files[0];
      this.file = file;
      this.cargarFile(file);
    },

    cargarFile(file){
      let reader = new FileReader();
      reader.onload = (e) => {
        this.imgMiniatura = e.target.result;
      }
      reader.readAsDataURL(file);
    },

    showMessage: function(msj){
      this.msj = msj;
      this.a = true;
      $("#msj").fadeIn(500);
      setTimeout(function(){
          $("#msj").fadeOut();
          this.a = false;
      }, 2000);
    },

    convertDate: function(date){
      if (date != '' && date != null) {
        var fecha = date.substring(0, 10);
        var hora = date.substring(11, 19);
        return fecha+'T'+hora;
      }
      return null;
    }





  },

  mounted(){
    var self = this;
    $('#selectFocos').on('change', function (e) {
    var optionSelected = $("option:selected", this);
    var valueSelected = this.value;
    console.log();
    if (valueSelected != '') {
      if (!self.existeFoco(valueSelected)) {
        self.focosSelected.push(self.buscarElemento(valueSelected, self.focos1));
      }
    }
    self.selectFocus = '';
    });

    $('#toggle-contacto').change(function() {
            if($(this).prop('checked')){
              console.log(true);
            }else{
              console.log(false);
            }
          });

  }


}
</script>

<style>
</style>
