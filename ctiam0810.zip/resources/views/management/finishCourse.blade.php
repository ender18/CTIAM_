@extends('layouts.app')

@section('content')

  <finish-course-component  :curso="{{$curso}}" :students="{{$students}}" :focos_string="'{{$focos_string}}'" :id="{{$id}}"></finish-course-component>

@endsection
