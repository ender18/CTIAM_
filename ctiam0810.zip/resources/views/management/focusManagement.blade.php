@extends('layouts.app')

@section('content')

  <focusmanagement-component :focos="{{$focos}}"></focusmanagement-component>

@endsection
