@extends('layouts.app')

@section('content')

<eventsmanagement-component :focos="{{$focos}}" :courses="{{$courses}}"></eventsmanagement-component>
@endsection
