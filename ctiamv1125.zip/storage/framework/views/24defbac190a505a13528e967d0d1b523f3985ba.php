


<?php $__env->startSection('content'); ?>

  <add-certifieds-component :course="<?php echo e($course); ?>" :students="<?php echo e($students); ?>"></add-certifieds-component>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctiam\resources\views/management/addCertifieds.blade.php ENDPATH**/ ?>