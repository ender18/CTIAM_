<template >

  <div class="container">
    <div class="row">
      <div class="col-12">
        <h1 class="bg-secondary text-white pt-2 pb-2 text-center">Misión</h1>
      </div>
      <div class="col-9 d-flex align-items-center">
        <p>{{mision[0].content}}</p>
      </div>
      <div class="col-3">
        <img v-bind:src="mision[0].file" alt="" class="img img-fluid">
      </div>

      <div class="col-12">
        <br>
        <h1 class="bg-secondary text-white pt-2 pb-2 text-center">Visión</h1>
      </div>
      <div class="col-3">
        <img v-bind:src="vision[0].file" alt="" class="img img-fluid">
      </div>
      <div class="col-9 d-flex align-items-center">
        <p>{{vision[0].content}}</p>
      </div>

      <div class="col-12">
        <br>
        <h1 class="bg-secondary text-white pt-2 pb-2 text-center">Objetivo General</h1>
      </div>
      <div class="col-9 d-flex align-items-center">
        <p>{{obj_general[0].content}}</p>
      </div>
      <div class="col-3">
        <img v-bind:src="obj_general[0].file" alt="" class="img img-fluid">
      </div>

      <div class="col-12">
        <br>
        <h1 class="bg-secondary text-white pt-2 pb-2 text-center">Objetivos Específicos</h1>
      </div>
      <div class="col-3">
        <img v-bind:src="img_obj_especifico[0].file" alt="" class="img img-fluid">
      </div>
      <div class="col-9 align-items-center">
        <p v-for="obj_esp in obj_especifico">{{obj_esp.content}}</p>
      </div>

      <div class="col-12">
        <br>
        <br>
        <h1 class="bg-secondary text-white pt-2 pb-2 text-center">Marco Normativo y funcional</h1>
        <br>
      </div>
      <div class="row d-flex justify-content-center">
        <div class="col-2" v-for="mn in marco_normativo">
          <a v-bind:href="mn.file" download>
            <img src="https://image.flaticon.com/icons/png/512/337/337946.png" alt="" class="img img-fluid">
          </a>

          <span class="text-center">{{mn.content}}</span>
        </div>


      </div>
      <div class="col-12">
        <hr>
        <br>
      </div>

    </div>
  </div>



</template>

<script>
export default {


  data(){
    return{


    }

  },

  props:['mision', 'vision', 'obj_general', 'obj_especifico', 'marco_normativo', 'img_obj_especifico']

}
</script>
