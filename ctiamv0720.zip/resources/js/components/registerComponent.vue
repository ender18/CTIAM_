
<template >

  <div class="container">
      <div class="row justify-content-center">
          <div class="col-md-8">
              <div class="card">
                  <div class="card-header text-center">Registro</div>

                  <div class="card-body">
                      <form class="form-group" method="POST" action="">
                        <div class="row">
                          <div class="col-12">
                            <h5>Información Básica</h5>
                            <hr>
                          </div>
                          <div class="col-6">
                            <label for="">Tipo de Documento</label>
                            <select class="form-control">
                              <option>Cedula de Ciudadanía</option>
                              <option>Cedula de extranjeria</option>
                              <option>Pasaporte</option>
                              <option>Tarjeta de identidad</option>
                            </select>
                          </div>
                          <div class="col-6">
                            <label for="">Número de identificación</label>
                            <input type="number" name="" value="" class="form-control">
                          </div>
                          <div class="col-6">
                            <label for="">Nombres</label>
                            <input type="text" name="" value="" class="form-control">
                          </div>
                          <div class="col-6">
                            <label for="">Apellidos</label>
                            <input type="text" name="" value="" class="form-control">
                          </div>
                          <div class="col-6">
                            <label for="">Correo</label>
                            <input type="email" name="" value="" class="form-control">
                          </div>
                          <div class="col-6">
                            <label for="">Fecha de Nacimiento</label>
                            <input type="date" name="" value="" class="form-control">
                          </div>
                          <div class="col-6">
                            <label for="">Dirección</label>
                            <input type="text" name="" value="" class="form-control">
                          </div>
                          <div class="col-6">
                            <label for="">Teléfono</label>
                            <input type="text" name="" value="" class="form-control">
                          </div>
                          <div class="col-12">
                            <br>
                            <h5>Información Complementaria</h5>
                            <hr>
                          </div>
                          <div class="col-6">
                            <label for="">Estado civil</label>
                            <select class="form-control">
                              <option>Soltera</option>
                              <option>Unión libre</option>
                              <option>Casada</option>
                              <option>Divorciada</option>
                              <option>Viuda</option>
                            </select>
                          </div>
                          <div class="col-6">
                            <label for="">¿Tiene hijos?</label>
                            <br>
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
                              <label class="form-check-label" for="inlineRadio1">Si</label>
                            </div>
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
                              <label class="form-check-label" for="inlineRadio2">No</label>
                            </div>
                          </div>
                          <div class="col-4">
                            <label for="">Nivel de estudio</label>
                            <select class="form-control">
                              <option>Profesional</option>
                              <option>Tecnóloga</option>
                              <option>Técnica</option>
                              <option>Secundaria</option>
                              <option>Primaria</option>
                              <option>No tiene</option>
                            </select>
                          </div>
                          <div class="col-4">
                            <label for="">Título obtenido</label>
                            <select class="form-control">
                              <option>Pregrado</option>
                              <option>Especialista</option>
                              <option>Magister</option>
                              <option>Doctorado</option>
                            </select>
                          </div>
                          <div class="col-4">
                            <label for="">Nombre del título obtenido</label>
                            <input type="text" name="" value="" class="form-control">
                          </div>
                          <div class="col-6">
                            <label for="">¿Actualmente estudia?</label>
                            <br>
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" name="inlineRadioOptions1" id="inlineRadio3" value="option1">
                              <label class="form-check-label" for="inlineRadio3">Si</label>
                            </div>
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" name="inlineRadioOptions1" id="inlineRadio4" value="option2">
                              <label class="form-check-label" for="inlineRadio4">No</label>
                            </div>
                          </div>
                          <div class="col-6">
                            <label for="">¿Qué está estudiando?</label>
                            <select class="form-control">
                              <option>Primaria</option>
                              <option>Secundaria</option>
                              <option>Tecnica</option>
                              <option>Tecnología</option>
                              <option>Pregrado</option>
                              <option>Postgrado</option>
                            </select>
                          </div>
                          <div class="col-4">
                            <label for="">¿Actualmente labora?</label>
                            <br>
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" name="inlineRadioOptions2" id="inlineRadio5" value="option1">
                              <label class="form-check-label" for="inlineRadio5">Si</label>
                            </div>
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" name="inlineRadioOptions2" id="inlineRadio6" value="option2">
                              <label class="form-check-label" for="inlineRadio6">No</label>
                            </div>
                          </div>
                          <div class="col-8">
                            <label for="">Sector en el que labora</label>
                            <select class="form-control">
                              <option>Agricultura, Ganadería, Caza, Silvicultura y Pesca</option>
                              <option>Explotación de Minas y Canteras </option>
                              <option>Industrias Manufactureras </option>
                              <option>Distribución de Agua; Evacuación y Tratamiento de Aguas Residuales, Gestión de Desechos y Actividades de Saneamiento Ambiental</option>
                              <option>Construcción </option>
                              <option>Transporte y Almacenamiento</option>
                              <option>Alojamiento y servicios de comida</option>
                              <option>Información y Comunicaciones </option>
                              <option>Actividades Financieras y de Seguros </option>
                              <option>Actividades Inmobiliarias </option>
                              <option>Actividades Profesionales, Científicas y Técnicas</option>
                              <option>Actividades de Servicios </option>
                              <option>Educación</option>
                              <option>Actividades de Atención de la Salud</option>
                              <option>Actividades Artísticas, de Entretenimiento y Recreación</option>
                              <option>Otras Actividades de Servicios</option>
                            </select>
                          </div>
                          <div class="col-6">
                          <label for="">Tiene negocio propio</label>
                          <br>
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions3" id="inlineRadio7" value="option1">
                            <label class="form-check-label" for="inlineRadio7">Si</label>
                          </div>
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions3" id="inlineRadio8" value="option2">
                            <label class="form-check-label" for="inlineRadio8">No</label>
                          </div>
                          </div>

                        </div>


                      </form>
                  </div>
              </div>
          </div>
      </div>
  </div>
</template>

<script>
export default {
}
</script>

<style lang="css" scoped>
</style>
