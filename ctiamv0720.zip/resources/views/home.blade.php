@extends('layouts.app')

@section('content')
  <div class="container">
    <div class="row">
      <div class="col-12 d-flex align-items-center text-center">
        <h1 class="display-2">Bienvenido, {{ Auth::user()->name }}</h1>
      </div>
    </div>

  </div>

@endsection
