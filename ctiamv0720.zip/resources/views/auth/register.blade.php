@extends('layouts.app')

@section('content')
  <register-component></register-component>

@endsection
