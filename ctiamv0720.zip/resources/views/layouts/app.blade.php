<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Bienvenido - CTIAM</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>
    <script src="{{ asset('js/myjs.js') }}" defer></script>
    <script src="https://kit.fontawesome.com/4aac046800.js" crossorigin="anonymous"></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->


    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('css/mycss.css') }}" rel="stylesheet">
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-secondary shadow-sm  ">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                    <img src="{{ asset('images/logo_ctiam.png') }}" alt="" class="img img-fluid">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto ">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto align-items-center">
                        <!-- Authentication Links -->
                        @guest
                            <li class="mr-3">
                              <a class="nav-link text-white" href="{{ route('conocenos')}}">Conócenos</a>
                            </li>
                            <li class="mr-3">
                              <a class="nav-link text-white" href="{{ route('miembros')}}">Nuestros Miembros</a>
                            </li>
                            <li class="mr-3">
                              <a class="nav-link text-white" href="{{ route('fundadoras')}}">Fundadoras</a>
                            </li>
                            <li class="mr-3">
                              <a class="nav-link text-white" href="{{ route('focos')}}">Focos</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link text-white" href="{{ route('login') }}"><button class="btn btn-light">Inicia Sesión</button></a>
                            </li>
                            @if (Route::has('register'))
                                <li class="nav-item">
                                    <a class="nav-link text-white" href="{{ route('register') }}"><button class="btn btn-dark">¡Registrate!</button></a>
                                </li>
                            @endif
                        @else
                          <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                 <span class="caret">Página principal</span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="{{ route('welcome')}}">Inicio</a>
                                <a class="dropdown-item" href="{{ route('conocenos')}}">Conócenos</a>
                                <a class="dropdown-item" href="{{ route('miembros')}}">Nuestros Miembros</a>
                                <a class="dropdown-item" href="{{ route('fundadoras')}}">Fundadoras</a>
                                <a class="dropdown-item" href="{{ route('focos')}}">Focos</a>
                            </div>
                          </li>

                           <li class="nav-item dropdown">
                             <a id="navbarDropdown" class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                  <span class="caret">Administración</span>
                             </a>

                             <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                 <a class="dropdown-item" href="/manageContent">
                                     Gestionar contenido del sitio
                                 </a>

                             </div>
                           </li>
                            <li class="mr-3">
                              <a class="nav-link text-white" href="{{ route('home')}}">Menú</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    {{ Auth::user()->name }} <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Cerrar sesión') }}
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
                                </div>
                            </li>
                        @endguest
                    </ul>
                </div>
            </div>
        </nav>



        <div class="py-4 bg-white">
            @yield('content')
        </div>

        <footer class="pt-4 bg-secondary shadow-sm">
          <!-- Footer Links -->
          <div class="container text-center text-light text-md-left ">

            <!-- Grid row -->
            <div class="row">

              <!-- Grid column -->
              <div class="col-md-6 mt-md-0 mt-3">

                <!-- Content -->
                <h5 class="text-uppercase "><strong>Descripción corta de la red de conocimiento CTIAM</strong></h5>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>

              </div>
              <!-- Grid column -->

              <hr class="clearfix w-100 d-md-none pb-3">

              <!-- Grid column -->
              <div class="col-md-3 mb-md-0 mb-3">

                <!-- Links -->
                <h5 class="text-uppercase"><strong>CONTACTO</strong></h5>

                <ul class="list-unstyled">
                  <li>
                    <span>Teléfono: 555555</span>
                  </li>
                  <li>
                    <span >Correo electrónico: <a class="text-light" href="#">info@ctiam.edu.co</a> </span>
                  </li>
                </ul>

              </div>
              <!-- Grid column -->

              <!-- Grid column -->
              <div class="col-md-3 mb-md-0 mb-3">

                <!-- Links -->
                <h5 class="text-uppercase"><strong>REDES SOCIALES</strong></h5>

                <ul class="list-unstyled">
                  <li>
                    <i class="fab fa-twitter fa-2x "></i><span> @ctiam_cucuta</span>
                  </li>
                  <li>
                    <i class="fab fa-facebook-square fa-2x"></i><span> Red CTIAM</span>
                  </li>
                  <li>
                    <i class="fab fa-instagram fa-2x"></i> <span> Red_ctiam</span>
                  </li>
                </ul>

              </div>
              <!-- Grid column -->

            </div>
            <!-- Grid row -->

          </div>
          <!-- Footer Links -->

          <!-- Copyright -->
          <div class="footer-copyright text-center py-3 text-white bg-dark" >© 2020 Copyright:
            <a class="text-light" href="https://ww2.ufps.edu.co/"> UFPS</a>
          </div>
          <!-- Copyright -->

        </footer>



    </div>
<!-- Footer -->
</body>
</html>
