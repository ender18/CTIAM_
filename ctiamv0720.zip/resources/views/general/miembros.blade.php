@extends('layouts.app')

@section('content')

<members-component :members = "{{$members}}"></members-component>


@endsection
