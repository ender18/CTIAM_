<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col-12 d-flex align-items-center text-center">
        <h1 class="display-2">Bienvenido, <?php echo e(Auth::user()->name); ?></h1>
      </div>
    </div>

  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctiam\resources\views/home.blade.php ENDPATH**/ ?>