

<?php $__env->startSection('content'); ?>

<indexmanagement-component :contents="<?php echo e($content); ?>"></indexmanagement-component>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctiam\resources\views/management/indexManagement.blade.php ENDPATH**/ ?>