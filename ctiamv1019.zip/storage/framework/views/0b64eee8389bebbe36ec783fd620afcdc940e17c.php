


<?php $__env->startSection('content'); ?>

<my-beneficiary-ally-component :cantidad_cursos="<?php echo e($cantidad_cursos); ?>"
                               :beneficiaries="<?php echo e($beneficiaries); ?>"
                               :cantidad_cursos_a_cargo="<?php echo e($cantidad_cursos_a_cargo); ?>"
                               ></my-beneficiary-ally-component>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctiam\resources\views/ally/myBeneficiaryAlly.blade.php ENDPATH**/ ?>