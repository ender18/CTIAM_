

<?php $__env->startSection('content'); ?>

<members-component :members = "<?php echo e($members); ?>" ></members-component>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctiam\resources\views/general/miembros.blade.php ENDPATH**/ ?>