

<?php $__env->startSection('content'); ?>


<founders-component :founders="<?php echo e($founders); ?>" :video_haz_parte="<?php echo e($video_haz_parte); ?>"></founders-component>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctiam\resources\views/general/founders.blade.php ENDPATH**/ ?>