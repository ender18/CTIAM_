<?php $__env->startSection('title'); ?>
  <title>Registro - CTIAM</title>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <register-component :aliados="<?php echo e($aliados); ?>"></register-component>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctiam\resources\views/auth/register.blade.php ENDPATH**/ ?>