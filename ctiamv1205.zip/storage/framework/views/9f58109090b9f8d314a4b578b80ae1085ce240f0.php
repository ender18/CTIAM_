

<?php $__env->startSection('title'); ?>
  <title>Focos - CTIAM</title>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<focus-component :focus1="<?php echo e($focus); ?>"></focus-component>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctiam\resources\views/general/focus.blade.php ENDPATH**/ ?>