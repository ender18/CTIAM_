

<?php $__env->startSection('title'); ?>
  <title>Error 401</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row d-flex justify-content-center">
      <div class="col-6">
        <img src="/images/error_page.png" alt="" class="img img-fluid">
      </div>
    </div>
    <div class="row">
      <div class="col-12 text-center pt-5 pb-5">
        <h1 class="display-4"><strong>¡Error 419, La página ha expirado!</strong></h1>
      </div>
    </div>
    <div class="row">
      <div class="col-12  text-center pt-1 pb-5">
        <h1 >Lo sentimos, vuelve a cargar la página</h1>
      </div>
    </div>

  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctiam\resources\views/errors/419.blade.php ENDPATH**/ ?>