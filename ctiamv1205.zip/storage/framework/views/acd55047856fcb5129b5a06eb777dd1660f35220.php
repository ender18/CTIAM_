<?php $__env->startSection('title'); ?>
  <title>Inicio - CTIAM</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <welcome-component

  :sliders="<?php echo e($sliders); ?>"
  :quienes_somos="<?php echo e($quienes_somos); ?>"
  :que_hacemos="<?php echo e($que_hacemos); ?>"
  :proyectos_realizados= "<?php echo e($proyectos_realizados); ?>"



  ></welcome-component>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctiam\resources\views/welcome.blade.php ENDPATH**/ ?>