

<?php $__env->startSection('title'); ?>
  <title>Administración de usuarios</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <manage-users-component :usuarios="<?php echo e($usuarios); ?>" :superadmin="<?php echo e($superadmin); ?>"></manage-users-component>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctiam\resources\views/management/manageUsers.blade.php ENDPATH**/ ?>