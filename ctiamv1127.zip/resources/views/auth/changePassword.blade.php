
@extends('layouts.app')

@section('content')
  <change-password-component></change-password-component>
@endsection
