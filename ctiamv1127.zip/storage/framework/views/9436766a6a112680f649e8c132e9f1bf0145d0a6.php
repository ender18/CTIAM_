

<?php $__env->startSection('title'); ?>
  <title>Mis actividades de formación asignadas</title>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<my-events-component :courses="<?php echo e($courses); ?>"></my-events-component>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctiam\resources\views/ally/myEvents.blade.php ENDPATH**/ ?>