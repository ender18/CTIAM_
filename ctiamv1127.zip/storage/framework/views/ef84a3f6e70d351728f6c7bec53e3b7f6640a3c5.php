


<?php $__env->startSection('title'); ?>
  <title>Mis actividades de formación</title>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<my-events-ally-component :my_courses="<?php echo e($my_courses); ?>" :my_groups="<?php echo e($my_groups); ?>" :my_beneficiaries="<?php echo e($my_beneficiaries); ?>"></my-events-ally-component>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctiam\resources\views/ally/myEventsAlly.blade.php ENDPATH**/ ?>