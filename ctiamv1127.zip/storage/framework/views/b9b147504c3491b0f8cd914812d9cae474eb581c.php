

<?php $__env->startSection('title'); ?>
  <title>Conócenos - CTIAM</title>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <aboutus-component
    :mision="<?php echo e($mision); ?>"     :vision="<?php echo e($vision); ?>"     :obj_general="<?php echo e($obj_general); ?>"     :obj_especifico = "<?php echo e($obj_especifico); ?>"  :marco_normativo = "<?php echo e($marco_normativo); ?>" :img_obj_especifico="<?php echo e($img_obj_especifico); ?>"></aboutus-component>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctiam\resources\views/general/conocenos.blade.php ENDPATH**/ ?>