

<?php $__env->startSection('title'); ?>
  <title>Calificar curso</title>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <finish-course-component  :curso="<?php echo e($curso); ?>" :students="<?php echo e($students); ?>" :focos_string="'<?php echo e($focos_string); ?>'" :id="<?php echo e($id_course); ?>" :id_group="<?php echo e($id_group); ?>"></finish-course-component>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctiam\resources\views/management/finishCourse.blade.php ENDPATH**/ ?>