<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Bienvenido - CTIAM</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/myjs.js')); ?>" defer></script>
    <script src="https://kit.fontawesome.com/4aac046800.js" crossorigin="anonymous"></script>


    <link rel="stylesheet" href="//unpkg.com/leaflet/dist/leaflet.css" />
    <script src="//unpkg.com/leaflet/dist/leaflet.js"></script>
    <script src="//unpkg.com/vue2-leaflet"></script>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Noto+Sans+TC" rel="stylesheet">

    <!-- Styles -->


    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="app">
      <?php echo $__env->yieldContent('content'); ?>



    </div>
<!-- Footer -->
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ctiam\resources\views/layouts/appBlank.blade.php ENDPATH**/ ?>